$.fn.rotatingLayers = function (settingsIn) {

	var settings = $.extend({}, {
		speed: 10000,
		side: 'left'
	}, settingsIn);

	var rotatingLayers = $(this);

	//setup structure
	var contents = rotatingLayers.children();
	$.each(contents, function (index, contentItem) {
		var toAppend = $('<div class="layer"><div class="content-container"></div></div>');
		rotatingLayers.append(toAppend);
		toAppend.find('.content-container').append(contentItem);
	});

	//strt animation

	var layers = rotatingLayers.find(".layer");

	rotatingLayers.addClass('rotating-layers');

	$.each(layers, function (index, layer) {
		var delay = -1 * (index / layers.size()) * settings.speed;

		$(layer).css({
			'animation-delay': delay + 'ms',
			'animation-duration': settings.speed + 'ms'
		});

		if (settings.side == 'right') {
			$(layer).css({
				'transform-origin': 'right center',
				'animation-name': 'layers-rotation-right'
			});
		}
	});
}